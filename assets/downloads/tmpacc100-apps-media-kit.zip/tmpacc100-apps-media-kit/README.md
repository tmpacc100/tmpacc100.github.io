# tmpacc100 Apps Media Kit

Generated: 2026-07-09

This package contains press copy, app links, social cards, QR cards, and short demo videos for tmpacc100 Apps.

## Public Hubs

- Apps: https://tmpacc100.github.io/
- Media Kit: https://tmpacc100.github.io/media-kit/
- Download ZIP: https://tmpacc100.github.io/assets/downloads/tmpacc100-apps-media-kit.zip
- Press Kit: https://tmpacc100.github.io/press/
- Links: https://tmpacc100.github.io/links/
- Use Cases: https://tmpacc100.github.io/use-cases/
- News: https://tmpacc100.github.io/news/
- Machine-readable catalog: https://tmpacc100.github.io/apps.json

## Store-ready Apps

- OpusScore (iOS / iPadOS): ピアノ演奏を端末内で解析し、楽譜上の現在位置を追いかけるiPhone/iPadアプリ。 [Store](https://apps.apple.com/jp/app/apple-store/id6783845152)
- ClipNest (macOS): Macのクリップボード履歴とスニペット展開を1つに。ネットワーク権限なし、買い切り、ローカルファーストなmacOSユーティリティ。 [Store](https://apps.apple.com/us/app/apple-store/id6777420616)
- GoNihon (iOS / Android / Web): Indonesian speakers向けのオフライン日本語学習アプリ。語彙、模擬試験、面接練習に対応。 [Store](https://apps.apple.com/id/app/apple-store/id6778385065)

## Landing-page Apps

- えらんでタイパ (iOS): 効率タイムとじっくりタイムを自分で選ぶ「禁止しない」時間デザインアプリ。 [Landing Page](https://tmpacc100.github.io/erande-taipa/)
- あさゆとり (iOS): 出発までの±ゆとり分とLive Activityで、朝の支度を落ち着かせるルーティンアプリ。 [Landing Page](https://tmpacc100.github.io/asayutori/)
- かうまえ (iOS): チェックリストと任意のAIリサーチガイドで、買い物の失敗を減らす台帳アプリ。 [Landing Page](https://tmpacc100.github.io/kaumae/)
- 栞 (iOS / iPadOS / macOS): 青空文庫の名作を、美しい縦書きとルビで読めるiPhone/iPad/Mac読書アプリ。 [Landing Page](https://tmpacc100.github.io/shiori/)

## Included Folders

- `social_cards/`: square and story PNG creatives.
- `videos/`: short MP4 demo/ad drafts.
- `qr/`: QR codes and QR cards for link hubs.
- `copy/`: press copy and ready-to-post drafts.
- `data/`: CSVs for app links, share links, use cases, QR links, and store status.

## Contact

asd95179517@gmail.com
