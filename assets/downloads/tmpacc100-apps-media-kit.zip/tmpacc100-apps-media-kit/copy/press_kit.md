# Press Kit

## まとめ紹介文

個人開発者 tmpacc100 は、日常の小さな判断を整えるiOSアプリ3本「えらんでタイパ」「あさゆとり」「かうまえ」を公開予定です。いずれもアカウント登録不要で、記録データは端末内に保存されます。

## えらんでタイパ

「えらんでタイパ」は、1日の時間を効率タイムとじっくりタイムに分けて記録する時間デザインアプリです。効率化を強制したり、スマホを禁止したりするのではなく、自分で選んだ時間の使い方と満たされ度をふりかえります。

短文:

```text
ぜんぶ効率じゃなくていい。効率タイムとじっくりタイムを自分で選ぶ「禁止しない」時間デザインアプリ。
```

## あさゆとり

「あさゆとり」は、朝のルーティンと出発時刻から、いま何分の余裕があるかを表示するアプリです。おでかけモードではロック画面やDynamic Islandに出発カウントダウンを表示できます。

短文:

```text
朝のゆとりが数字で見える。出発までの±ゆとり分とLive Activityで、朝の支度を落ち着かせるルーティンアプリ。
```

## かうまえ

「かうまえ」は、買う前の迷いや条件を整理する買い物台帳アプリです。カテゴリ別チェックリストに加え、任意のClaude APIキーを設定すると商品ごとのAIリサーチガイドを生成できます。

短文:

```text
買うまえに、ひと呼吸。チェックリストと任意のAIリサーチガイドで、買い物の失敗を減らす台帳アプリ。
```

## 素材

- LP: <https://tmpacc100.github.io/>
- 公開Press Kit: <https://tmpacc100.github.io/press/>
- Media Kit: <https://tmpacc100.github.io/media-kit/>
- Media Kit ZIP: <https://tmpacc100.github.io/assets/downloads/tmpacc100-apps-media-kit.zip>
- Outreach Kit: <https://tmpacc100.github.io/outreach/>
- Outreach CSV: <https://tmpacc100.github.io/assets/downloads/tmpacc100-outreach-queue.csv>
- Share Kit: <https://tmpacc100.github.io/share/>
- Share CSV: <https://tmpacc100.github.io/assets/downloads/tmpacc100-share-booster-links.csv>
- Install Kit: <https://tmpacc100.github.io/install/>
- Install CSV: <https://tmpacc100.github.io/assets/downloads/tmpacc100-install-links.csv>
- Directory Kit: <https://tmpacc100.github.io/directories/>
- Directory CSV: <https://tmpacc100.github.io/assets/downloads/tmpacc100-directory-submissions.csv>
- ニュース/プレスリリース: <https://tmpacc100.github.io/news/>
- リンクインバイオ/QR: <https://tmpacc100.github.io/links/>
- 用途別SEO LP: <https://tmpacc100.github.io/use-cases/>
- apps.json: <https://tmpacc100.github.io/apps.json>
- えらんでタイパ: <https://tmpacc100.github.io/erande-taipa/>
- あさゆとり: <https://tmpacc100.github.io/asayutori/>
- かうまえ: <https://tmpacc100.github.io/kaumae/>
- OpusScore: <https://tmpacc100.github.io/opusscore/>
- OpusScore App Store: <https://apps.apple.com/jp/app/apple-store/id6783845152>
- ClipNest: <https://tmpacc100.github.io/clipnest/>
- ClipNest Mac App Store: <https://apps.apple.com/us/app/apple-store/id6777420616>
- 栞: <https://tmpacc100.github.io/shiori/>
- GoNihon: <https://tmpacc100.github.io/gonihon/>
- GoNihon App Store: <https://apps.apple.com/id/app/apple-store/id6778385065>
- スクリーンショット: `/Users/makinoshii/pj/tmpacc100.github.io/assets/`
- SNS/広告カード: `/Users/makinoshii/pj/appads/outputs/social_cards/`
- 連絡先: `asd95179517@gmail.com`

## 追加アプリ短文

OpusScore:

```text
演奏を聴いて、自動で譜めくり。ピアノ演奏を端末内で解析し、楽譜上の現在位置を追いかけるiPhone/iPadアプリ。
```

ClipNest:

```text
Macのクリップボード履歴とスニペット展開を1つに。ネットワーク権限なし、買い切り、ローカルファーストなmacOSユーティリティ。
```

栞:

```text
1日10分、名作を。青空文庫の名作を、美しい縦書きとルビで読めるiPhone/iPad/Mac読書アプリ。
```

GoNihon:

```text
Belajar bahasa Jepang untuk kerja di Jepang. Indonesian speakers向けのオフライン日本語学習アプリ。
```
