# Ready To Post

確認日: 2026-07-09

外部アカウントへの投稿は未実行です。以下は、手動投稿・広告下書き・DMでそのまま使うために生成済みの配布URLと素材です。

## すぐにストア流入へ送れるアプリ

OpusScore:

- X / Threads: <https://tmpacc100.github.io/go/opusscore/x/>
- TikTok: <https://tmpacc100.github.io/go/opusscore/tiktok/>
- YouTube Shorts: <https://tmpacc100.github.io/go/opusscore/youtube-shorts/>
- 画像: <https://tmpacc100.github.io/assets/social/opusscore-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/opusscore-short.mp4>

ClipNest:

- X / Threads: <https://tmpacc100.github.io/go/clipnest/x/>
- TikTok: <https://tmpacc100.github.io/go/clipnest/tiktok/>
- YouTube Shorts: <https://tmpacc100.github.io/go/clipnest/youtube-shorts/>
- 画像: <https://tmpacc100.github.io/assets/social/clipnest-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/clipnest-short.mp4>

GoNihon:

- X / Threads: <https://tmpacc100.github.io/go/gonihon/x/>
- TikTok: <https://tmpacc100.github.io/go/gonihon/tiktok/>
- YouTube Shorts: <https://tmpacc100.github.io/go/gonihon/youtube-shorts/>
- 画像: <https://tmpacc100.github.io/assets/social/gonihon-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/gonihon-short.mp4>

## 公開待ちLPへ送るアプリ

えらんでタイパ:

- X / Threads: <https://tmpacc100.github.io/go/erande-taipa/x/>
- TikTok: <https://tmpacc100.github.io/go/erande-taipa/tiktok/>
- 画像: <https://tmpacc100.github.io/assets/social/erande-taipa-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/erande-taipa-short.mp4>

あさゆとり:

- X / Threads: <https://tmpacc100.github.io/go/asayutori/x/>
- TikTok: <https://tmpacc100.github.io/go/asayutori/tiktok/>
- 画像: <https://tmpacc100.github.io/assets/social/asayutori-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/asayutori-short.mp4>

かうまえ:

- X / Threads: <https://tmpacc100.github.io/go/kaumae/x/>
- TikTok: <https://tmpacc100.github.io/go/kaumae/tiktok/>
- 画像: <https://tmpacc100.github.io/assets/social/kaumae-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/kaumae-short.mp4>

栞:

- X / Threads: <https://tmpacc100.github.io/go/shiori/x/>
- TikTok: <https://tmpacc100.github.io/go/shiori/tiktok/>
- 画像: <https://tmpacc100.github.io/assets/social/shiori-square.png>
- 動画: <https://tmpacc100.github.io/assets/video/shiori-short.mp4>

## 全リンク

- 公開ページ: <https://tmpacc100.github.io/go/>
- CSV: `campaigns/share_links.csv`
- 投稿キュー: `campaigns/posting_queue.csv`
