# Social Posts And Short Video Scripts

## えらんでタイパ

### X / Threads

```text
タイパを上げたいのに、全部を効率化しようとして疲れる日がある。

「えらんでタイパ」は、1日の時間を
⚡効率タイム
🌿じっくりタイム
に分けて、満たされ度つきでふりかえるiOSアプリです。

ぜんぶ効率じゃなくていい。
https://tmpacc100.github.io/erande-taipa/
```

```text
時間管理アプリを作りました。

ブロックしない。
説教しない。
「今日は効率で片づける時間」と「ちゃんと味わう時間」を自分で選ぶだけ。

えらんでタイパ
https://tmpacc100.github.io/erande-taipa/
```

### TikTok / Shorts

```text
0-2秒: 「タイパを意識しすぎて、逆に疲れてない?」
3-6秒: 画面録画: 効率タイムとじっくりタイムを並べる
7-11秒: 画面録画: 満たされ度を記録
12-15秒: 「ぜんぶ効率じゃなくていい。えらんでタイパ」
```

## あさゆとり

### X / Threads

```text
朝の支度で一番ほしいのは、完璧なルーティンより「今まだ間に合う?」の答えかもしれない。

あさゆとりは、出発までの残り時間からルーティンの残り所要時間を引いて、±ゆとり分を表示するiOSアプリです。

https://tmpacc100.github.io/asayutori/
```

```text
朝のルーティンアプリ「あさゆとり」を作りました。

出発時刻と準備ステップを入れると、
いま何分余裕があるかが見えます。
おでかけモードではロック画面にカウントダウン。

https://tmpacc100.github.io/asayutori/
```

### TikTok / Shorts

```text
0-2秒: 「朝、時計を見るたびに焦る人へ」
3-6秒: 画面録画: 出発時刻とルーティン
7-10秒: 画面録画: ±ゆとり分
11-15秒: 画面録画: ロック画面カウントダウン
16秒: 「朝のゆとりが数字で見える。あさゆとり」
```

## かうまえ

### X / Threads

```text
買ってから「もっと調べればよかった」と思うことが多いので、買う前専用の台帳アプリを作りました。

予算、条件、チェックリスト、見送った理由まで残せます。
任意でAIリサーチガイドも作れます。

かうまえ
https://tmpacc100.github.io/kaumae/
```

```text
欲しいと思った瞬間に買うのではなく、まず台帳に入れる。

「かうまえ」は、失敗しない買い物のためのチェックリストアプリです。
買う、見送る、どちらもちゃんと正解にする。

https://tmpacc100.github.io/kaumae/
```

### TikTok / Shorts

```text
0-2秒: 「その買い物、あとで後悔しない?」
3-6秒: 画面録画: 商品と予算を登録
7-10秒: 画面録画: チェックリスト
11-14秒: 画面録画: AIリサーチガイド
15秒: 「買うまえに、ひと呼吸。かうまえ」
```

## インフルエンサーDMテンプレ

```text
突然失礼します。個人開発でiOSアプリを作っています。

日常の小さな困りごとを扱うアプリで、もし動画ネタに合いそうなら触っていただけないかと思いご連絡しました。

・えらんでタイパ: タイパ疲れ向けの時間デザイン
・あさゆとり: 朝の出発までのゆとり分を見える化
・かうまえ: 買う前のチェックリスト台帳

公開後のApp Storeリンクと素材一式をお送りします。PR表記が必要な場合はもちろん対応します。
```

## OpusScore

### X / Threads

```text
ピアノを弾いているとき、譜めくりで手が止まる問題をアプリで解きたい。

OpusScoreは、演奏をマイクで聴いて、楽譜上の現在位置を追いかける自動譜めくりアプリです。
MusicXMLの取り込みにも対応。音声処理は端末内のみ。

https://tmpacc100.github.io/opusscore/
```

### TikTok / Shorts

```text
0-2秒: 「ピアノ中の譜めくり、地味に大変」
3-7秒: 画面録画: 楽譜を開く
8-12秒: 画面録画: 演奏位置が追従する様子
13-16秒: 「演奏を聴いて、自動で譜めくり。OpusScore」
```

## ClipNest

### X / Threads

```text
Macのクリップボード履歴とスニペット展開を1つにしたアプリを作っています。

ClipNest
・Cmd+Shift+Vで履歴検索
・;sig みたいなトリガーでテンプレ展開
・買い切り
・ネットワーク権限なし

https://tmpacc100.github.io/clipnest/
```

### Shorts / Demo

```text
0-2秒: "Your Mac clipboard should not need an account."
3-6秒: Show clipboard history search
7-10秒: Type ;sig and expand a snippet
11-14秒: "ClipNest. Local on your Mac. Buy once."
```

## 栞

### X / Threads

```text
青空文庫の名作を、スマホでちゃんと読みたくて読書アプリを作っています。

栞は、美しい縦書き・ルビ・テーマ別コレクション・本棚・読書統計に対応したアプリです。

1日10分、名作を。
https://tmpacc100.github.io/shiori/
```

### TikTok / Shorts

```text
0-2秒: 「1日10分だけ名作を読む」
3-6秒: 画面録画: コレクションから作品を選ぶ
7-11秒: 画面録画: 縦書きの読書画面
12-15秒: 「青空文庫を、美しい縦書きで。栞」
```

## GoNihon

### X / Threads

```text
GoNihon is an offline Japanese-learning app for Indonesian speakers preparing to work in Japan.

Lessons, vocabulary, listening, mock tests, interview practice, XP, streaks, and progress are stored locally.

https://tmpacc100.github.io/gonihon/
```

### TikTok / Shorts

```text
0-2秒: "Mau kerja di Jepang?"
3-6秒: Show lesson and vocabulary practice
7-10秒: Show interview practice
11-14秒: Show XP/streak progress
15秒: "GoNihon. Belajar bahasa Jepang offline."
```
